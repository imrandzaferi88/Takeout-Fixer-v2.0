package com.takeout.fixer

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.ProgressBar
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.exifinterface.media.ExifInterface
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.*
import java.text.SimpleDateFormat
import java.util.*
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream
import kotlin.math.abs

class MainActivity : AppCompatActivity() {

    private var inputUri: Uri? = null
    private lateinit var btnSelectInput: Button
    private lateinit var btnStart: Button
    private lateinit var tvInputPath: TextView
    private lateinit var tvStatus: TextView
    private lateinit var tvLog: TextView
    private lateinit var progressBar: ProgressBar

    private val CHANNEL_ID = "takeout_fixer_channel"
    private val NOTIF_ID = 1001

    private val pickInputLauncher = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            inputUri = uri
            tvInputPath.text = "File selezionato: $uri"
            btnStart.isEnabled = true
            log("File ZIP selezionato con successo.")
        }
    }

    private val createOutputLauncher = registerForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { outUri ->
        val inUri = inputUri
        if (inUri != null && outUri != null) {
            processZip(inUri, outUri)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        createNotificationChannel()
        checkNotificationPermission()

        btnSelectInput = findViewById(R.id.btnSelectInput)
        btnStart = findViewById(R.id.btnStart)
        tvInputPath = findViewById(R.id.tvInputPath)
        tvStatus = findViewById(R.id.tvStatus)
        tvLog = findViewById(R.id.tvLog)
        progressBar = findViewById(R.id.progressBar)

        btnSelectInput.setOnClickListener {
            pickInputLauncher.launch(arrayOf("application/zip", "application/x-zip-compressed", "*/*"))
        }

        btnStart.setOnClickListener {
            createOutputLauncher.launch("Takeout_Ordinato_FIXED.zip")
        }
    }

    private fun checkNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 101)
            }
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Avanzamento Takeout Fixer",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Notifiche per l'unione dei metadati e compressione"
            }
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)
        }
    }

    private fun updateProgress(pct: Int, status: String, max: Int = 100) {
        runOnUiThread {
            progressBar.progress = pct
            tvStatus.text = status
        }
        val notifManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val notif = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle("Takeout Fixer in esecuzione")
            .setContentText(status)
            .setProgress(max, pct, false)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .build()
        notifManager.notify(NOTIF_ID, notif)
    }

    private fun sendCompletionNotification(title: String, message: String) {
        val notifManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val notif = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_sys_download_done)
            .setContentTitle(title)
            .setContentText(message)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .build()
        notifManager.cancel(NOTIF_ID)
        notifManager.notify(1002, notif)
    }

    private fun log(msg: String) {
        runOnUiThread {
            tvLog.append("$msg\n")
        }
    }

    private fun findJsonForMedia(mediaFile: File): File? {
        val parent = mediaFile.parentFile ?: return null
        val name = mediaFile.name
        val stem = mediaFile.nameWithoutExtension
        val ext = mediaFile.extension

        val children = parent.listFiles() ?: return null
        for (f in children) {
            if (f.name.startsWith("$name.") && f.name.endsWith(".json")) return f
        }
        val direct = File(parent, "$stem.json")
        if (direct.exists()) return direct

        if (stem.contains("(") && stem.endsWith(")")) {
            val idx = stem.lastIndexOf("(")
            val base = stem.substring(0, idx)
            val num = stem.substring(idx)
            val swapped = File(parent, "$base.$ext$num.json")
            if (swapped.exists()) return swapped
        }
        return null
    }

    private fun convertToRationalLatLon(deg: Double): String {
        val d = abs(deg)
        val degrees = d.toInt()
        val minutesFloat = (d - degrees) * 60
        val minutes = minutesFloat.toInt()
        val seconds = ((minutesFloat - minutes) * 60 * 10000).toInt()
        return "$degrees/1,$minutes/1,$seconds/10000"
    }

    private fun processZip(inUri: Uri, outUri: Uri) {
        btnSelectInput.isEnabled = false
        btnStart.isEnabled = false

        lifecycleScope.launch(Dispatchers.IO) {
            val workDir = File(cacheDir, "takeout_work_${System.currentTimeMillis()}")
            workDir.mkdirs()

            val yearStats = mutableMapOf<String, Int>()
            var gpsCount = 0
            var datedCount = 0

            try {
                updateProgress(5, "1/3 Estrazione archivio Takeout...")
                log("Decompressione in memoria interna...")

                contentResolver.openInputStream(inUri)?.use { rawIn ->
                    ZipInputStream(BufferedInputStream(rawIn)).use { zis ->
                        var entry: ZipEntry? = zis.nextEntry
                        val buffer = ByteArray(65536)
                        while (entry != null) {
                            if (!entry.isDirectory) {
                                val outFile = File(workDir, entry.name)
                                outFile.parentFile?.mkdirs()
                                FileOutputStream(outFile).use { fos ->
                                    var len: Int
                                    while (zis.read(buffer).also { len = it } > 0) {
                                        fos.write(buffer, 0, len)
                                    }
                                }
                            }
                            zis.closeEntry()
                            entry = zis.nextEntry
                        }
                    }
                }

                updateProgress(35, "2/3 Applicazione metadati e calcolo cartelle...")
                val allFiles = workDir.walkTopDown().filter { it.isFile && !it.name.endsWith(".json", true) }.toList()
                val total = allFiles.size
                var merged = 0

                val exifDateFormat = SimpleDateFormat("yyyy:MM:dd HH:mm:ss", Locale.US).apply {
                    timeZone = TimeZone.getDefault()
                }
                val folderDateFormat = SimpleDateFormat("yyyy/MM - MMMM", Locale.ITALIAN).apply {
                    timeZone = TimeZone.getDefault()
                }
                val yearFormat = SimpleDateFormat("yyyy", Locale.US).apply {
                    timeZone = TimeZone.getDefault()
                }

                val targetPathMap = mutableMapOf<File, String>()

                for ((index, mediaFile) in allFiles.withIndex()) {
                    val jsonFile = findJsonForMedia(mediaFile)
                    var takenTime = mediaFile.lastModified()

                    if (jsonFile != null && jsonFile.exists()) {
                        try {
                            val jsonObj = JSONObject(jsonFile.readText())
                            val ts = jsonObj.optJSONObject("photoTakenTime")?.optString("timestamp", "0")?.toLongOrNull() ?: 0L
                            val geo = jsonObj.optJSONObject("geoData")
                            val lat = geo?.optDouble("latitude", 0.0) ?: 0.0
                            val lon = geo?.optDouble("longitude", 0.0) ?: 0.0
                            val desc = jsonObj.optString("description", "")

                            if (ts > 0) {
                                takenTime = ts * 1000
                                datedCount++
                            }

                            val ext = mediaFile.extension.lowercase()
                            if (ext == "jpg" || ext == "jpeg" || ext == "webp") {
                                val exif = ExifInterface(mediaFile)
                                if (ts > 0) {
                                    val dateStr = exifDateFormat.format(Date(takenTime))
                                    exif.setAttribute(ExifInterface.TAG_DATETIME, dateStr)
                                    exif.setAttribute(ExifInterface.TAG_DATETIME_ORIGINAL, dateStr)
                                    exif.setAttribute(ExifInterface.TAG_DATETIME_DIGITIZED, dateStr)
                                }
                                if (lat != 0.0 || lon != 0.0) {
                                    exif.setAttribute(ExifInterface.TAG_GPS_LATITUDE, convertToRationalLatLon(lat))
                                    exif.setAttribute(ExifInterface.TAG_GPS_LATITUDE_REF, if (lat >= 0) "N" else "S")
                                    exif.setAttribute(ExifInterface.TAG_GPS_LONGITUDE, convertToRationalLatLon(lon))
                                    exif.setAttribute(ExifInterface.TAG_GPS_LONGITUDE_REF, if (lon >= 0) "E" else "W")
                                    gpsCount++
                                }
                                if (desc.isNotEmpty()) {
                                    exif.setAttribute(ExifInterface.TAG_IMAGE_DESCRIPTION, desc)
                                }
                                exif.saveAttributes()
                            }

                            if (ts > 0) {
                                mediaFile.setLastModified(takenTime)
                            }
                            merged++
                        } catch (e: Exception) {
                            log("Ignorato JSON per ${mediaFile.name}: ${e.message}")
                        }
                    }

                    val dateObj = Date(takenTime)
                    val folderName = folderDateFormat.format(dateObj)
                    val yearStr = yearFormat.format(dateObj)
                    yearStats[yearStr] = (yearStats[yearStr] ?: 0) + 1

                    targetPathMap[mediaFile] = "$folderName/${mediaFile.name}"

                    if (index % 20 == 0 || index == total - 1) {
                        val pct = 35 + ((index + 1) * 35 / total.coerceAtLeast(1))
                        updateProgress(pct, "2/3 Metadati e ordinamento: ${index + 1}/$total")
                    }
                }

                updateProgress(70, "3/3 Creazione ZIP con struttura Anno/Mese...")
                log("Compressione e riorganizzazione cartelle in corso...")

                contentResolver.openOutputStream(outUri)?.use { rawOut ->
                    ZipOutputStream(BufferedOutputStream(rawOut)).use { zos ->
                        val buffer = ByteArray(65536)
                        for ((index, mediaFile) in allFiles.withIndex()) {
                            val relPath = targetPathMap[mediaFile] ?: mediaFile.name
                            val zipEntry = ZipEntry(relPath).apply {
                                time = mediaFile.lastModified()
                            }
                            zos.putNextEntry(zipEntry)
                            FileInputStream(mediaFile).use { fis ->
                                var len: Int
                                while (fis.read(buffer).also { len = it } > 0) {
                                    zos.write(buffer, 0, len)
                                }
                            }
                            zos.closeEntry()

                            if (index % 25 == 0 || index == total - 1) {
                                val pct = 70 + ((index + 1) * 30 / total.coerceAtLeast(1))
                                updateProgress(pct, "3/3 Scrittura archivio: ${index + 1}/$total")
                            }
                        }
                    }
                }

                updateProgress(100, "Operazione completata!")
                sendCompletionNotification("Takeout Fixer", "Archivio completato con successo: $merged file uniti!")

                val statsBuilder = StringBuilder()
                statsBuilder.append("Totale file multimediali: $total\n")
                statsBuilder.append("Metadati JSON uniti: $merged\n")
                statsBuilder.append("File con coordinate GPS: $gpsCount\n\n")
                statsBuilder.append("Suddivisione per Anno:\n")
                yearStats.toSortedMap(compareByDescending { it }).forEach { (anno, count) ->
                    statsBuilder.append("• $anno: $count file\n")
                }

                withContext(Dispatchers.Main) {
                    AlertDialog.Builder(this@MainActivity)
                        .setTitle("Statistiche di Elaborazione")
                        .setMessage(statsBuilder.toString())
                        .setPositiveButton("OK", null)
                        .show()
                }

            } catch (e: Exception) {
                updateProgress(0, "Errore durante l'elaborazione")
                log("ERRORE: ${e.message}")
                sendCompletionNotification("Takeout Fixer", "Errore durante l'elaborazione: ${e.message}")
            } finally {
                workDir.deleteRecursively()
                withContext(Dispatchers.Main) {
                    btnSelectInput.isEnabled = true
                    btnStart.isEnabled = true
                }
            }
        }
    }
}
